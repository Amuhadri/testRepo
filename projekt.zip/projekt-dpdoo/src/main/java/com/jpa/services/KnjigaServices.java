package com.jpa.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpa.dao.HomeRepository;
import com.jpa.model.Knjiga;

@Service
public class KnjigaServices {
	
	@Autowired
	HomeRepository homeRepo;
	
	
	public List<Knjiga> zbrojiSve(LocalDate datum){
		
		List<Knjiga> knjiga = null;
		knjiga = homeRepo.proba(datum);
		
		return knjiga;

	}
	
	
	

}
