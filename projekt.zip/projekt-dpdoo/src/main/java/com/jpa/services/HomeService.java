package com.jpa.services;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.sql.Date;

import org.springframework.stereotype.Service;

import com.jpa.model.Const;
import com.jpa.model.Knjiga;
import com.jpa.utils.Utils;

@Service
public class HomeService {

	public void spremiTxt(String stringTxt, int poslovnica) throws IOException {

		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(obradiTxt(stringTxt));
		strBuilder.append(Utils.formatDatumaVremena());

		String datoteka = dohvatiPutanjuDatoteke(poslovnica);

		try {

			FileOutputStream outputStream = new FileOutputStream(datoteka);
			byte[] strToBytes = strBuilder.toString().getBytes();
			outputStream.write(strToBytes);
			outputStream.close();

		} catch (Exception e) {
			System.out.println("Nije odabrana poslovnica!");
		}
	}

	public String obradiTxt(String txtZaObradu) {

		String obradjenTxt = null;

		int pocIndx = txtZaObradu.indexOf("Proizvodnja:");
		int kraIndx = txtZaObradu.indexOf("Povrat") - 119;
		obradjenTxt = txtZaObradu.substring(pocIndx, kraIndx);

		return obradjenTxt;

	}
	

	public ArrayList<Double> dohvatiPodatkeProPot(String putanjaDatoteke) throws FileNotFoundException, IOException {

		ArrayList<Double> podaciPotPro = new ArrayList<>();

		try (BufferedReader br = new BufferedReader(new FileReader(putanjaDatoteke));) {

			String st;
			while ((st = br.readLine()) != null) {

				st = Utils.makniRazmake(st);
				st = st.replaceAll(",", ".");

				int indeksPoc = st.indexOf(":");

				if ((indeksPoc != -1) && (!st.equals("Potrošnja:") && (!st.equals("Proizvodnja:")))) {
					String[] keyValue = st.split(":");

					podaciPotPro.add(Double.valueOf(keyValue[1].toString()));
				}

			}
			
			br.close();
			System.out.println(podaciPotPro);

		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return podaciPotPro;
	}

	public Knjiga spremiPodatkeUObjekt(int poslovnica, Date odabraniDatum) throws FileNotFoundException, IOException {

		ArrayList<Double> podaciUtroska = dohvatiPodatkeProPot(dohvatiPutanjuDatoteke(poslovnica));

		Knjiga knjiga = new Knjiga();

		knjiga.setBijT550Proizvodnja(podaciUtroska.get(0));
		knjiga.setPolT850Proizvodnja(podaciUtroska.get(1));
		knjiga.setCrnT110Proizvodnja(podaciUtroska.get(2));
		knjiga.setRazBProizvodnja(podaciUtroska.get(3));
		knjiga.setKukBProizvodnja(podaciUtroska.get(4));
		knjiga.setMjesBProizvodnja(podaciUtroska.get(5));
		knjiga.setPosVrsteBProizvodnja(podaciUtroska.get(6));
		knjiga.setPecBProizvodnja(podaciUtroska.get(7));
		knjiga.setOstProizvodiBproizvodnja(podaciUtroska.get(8));
		knjiga.setSmjBProizvodnja(podaciUtroska.get(9));
		knjiga.setKonBProizvodnja(podaciUtroska.get(10));
		knjiga.setUkupnoProizvodnja(podaciUtroska.get(11));
		knjiga.setBijT550Potrosnja(podaciUtroska.get(12));
		knjiga.setPolT850Potrosnja(podaciUtroska.get(13));
		knjiga.setCrnT110Potrosnja(podaciUtroska.get(14));
		knjiga.setRazBPotrosnja(podaciUtroska.get(15));
		knjiga.setKukBPotrosnja(podaciUtroska.get(16));
		knjiga.setSmjBPotrosnja(podaciUtroska.get(17));
		knjiga.setKonBPotrosnja(podaciUtroska.get(18));
		knjiga.setUkupnoPotrosnja(podaciUtroska.get(19));
		knjiga.setPoslovnica(poslovnica);
		knjiga.setOdabraniDatum(odabraniDatum);

		return knjiga;

	}

	public String dohvatiPutanjuDatoteke(int poslovnica) {

		String putanja = null;

		switch (poslovnica) {
		case 1:
			putanja = Const.PUTANJA_VOLTINO;
			break;
		case 2:
			putanja = Const.PUTANJA_JARUN;
			break;
		case 3:
			putanja = Const.PUTANJA_VRBIK;
			break;
		}

		return putanja;

	}

}
