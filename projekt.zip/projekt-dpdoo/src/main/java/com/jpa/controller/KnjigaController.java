package com.jpa.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jpa.dao.HomeRepository;
import com.jpa.model.Knjiga;
import com.jpa.services.KnjigaServices;

@Controller
@RequestMapping("utrosak")
public class KnjigaController {

	@Autowired
	HomeRepository homeRepo;

	@Autowired
	KnjigaServices knjigaServ;
	
	

	@GetMapping("/pojedinacno")
	public String odaberiDatumPregleda(Model model, Knjiga knjiga) {
		return "pojedinacni-pregled";
	}

	@PostMapping("/pojedinacno")
	public String prikaziUtrosak(Model model, Knjiga knjiga) throws IOException {

		Date datum = knjiga.getOdabraniDatum();
		List<Knjiga> knjigeSve = homeRepo.dohvatiSve(datum.toLocalDate());
		List<Knjiga> zbrojKnjige = knjigaServ.zbrojiSve(datum.toLocalDate());
		
		model.addAttribute("knjigeSve", knjigeSve);
		model.addAttribute("zbrojKnjige", zbrojKnjige);

		return "pojedinacni-pregled";
	}

}
