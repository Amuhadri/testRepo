package com.jpa.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jpa.dao.HomeRepository;
import com.jpa.model.KeubTxt;
import com.jpa.model.Knjiga;
import com.jpa.services.HomeService;

@Controller
@RequestMapping("/")
public class HomeController {

	@Autowired
	HomeRepository homeRepo;

	@Autowired
	HomeService homeService;

	@GetMapping
	public String home(Model model, KeubTxt keubTxt) {
		return "home";
	}

	@PostMapping("/save")
	public String createStringTxt(Model model, KeubTxt keubTxt) throws IOException {

		if (!(keubTxt.getPoslovnica() == 0)) {
			homeService.spremiTxt(keubTxt.getUnosString(), keubTxt.getPoslovnica());
			Knjiga knjiga = homeService.spremiPodatkeUObjekt(keubTxt.getPoslovnica(), keubTxt.getOdabraniDatum());
			homeRepo.save(knjiga);
		}
		
		return "redirect:/";

	}

}
