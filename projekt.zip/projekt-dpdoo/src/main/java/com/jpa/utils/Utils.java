package com.jpa.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Utils {


	public static String makniRazmake(String stringTxt) {

		stringTxt = stringTxt.replaceAll("\\s+", "");
		return stringTxt;

	}

	public static String formatDatumaVremena() {

		Format f = new SimpleDateFormat("dd/MM/yy ** hh-mm-ss");
		String datum = " \n".concat(f.format(new Date()));

		return datum;
	}
	
	


}
