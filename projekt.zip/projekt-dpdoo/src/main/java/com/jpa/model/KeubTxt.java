package com.jpa.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class KeubTxt {
	
	@Id
	private long id;
	private String unosString;
	private int poslovnica;
	private Date odabraniDatum;
	
	public KeubTxt() {
		
	}
	public KeubTxt(long id, String unosString, int poslovnica, Date odabraniDatum) {
		super();
		this.id = id;
		this.unosString = unosString;
		this.poslovnica = poslovnica;
		this.odabraniDatum = odabraniDatum;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUnosString() {
		return unosString;
	}
	public void setUnosString(String unosString) {
		this.unosString = unosString;
	}
	public int getPoslovnica() {
		return poslovnica;
	}
	public void setPoslovnica(int poslovnica) {
		this.poslovnica = poslovnica;
	}
	public Date getOdabraniDatum() {
		return odabraniDatum;
	}
	public void setOdabraniDatum(Date odabraniDatum) {
		this.odabraniDatum = odabraniDatum;
	}
	
	
	
	
	
}
