package com.jpa.model;

public class Const {

	
	public static final String PUTANJA_VOLTINO = "src/main/resources/keubTxt/voltinoKeub.txt";
	public static final String PUTANJA_JARUN = "src/main/resources/keubTxt/jarunKeub.txt";
	public static final String PUTANJA_VRBIK = "src/main/resources/keubTxt/vrbikKeub.txt";
}
