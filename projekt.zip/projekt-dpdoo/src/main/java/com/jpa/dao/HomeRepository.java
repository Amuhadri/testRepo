package com.jpa.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.jpa.model.Knjiga;

public interface HomeRepository extends PagingAndSortingRepository<Knjiga, Long> {
	
	
	@Query(nativeQuery = true, value ="select * from utrosasveposlovnice where odabranidatum = ?1")
	public List<Knjiga> dohvatiSve(LocalDate datum);
	
	@Query(nativeQuery = true, value ="select * from utrosasveposlovnice where odabranidatum = ?1")
	public List<Knjiga> dohvatiZbrojenuProizvodnju(LocalDate datum);
	
	@Query(nativeQuery = true, value ="SELECT\r\n"
			+ "sum(utrosasveposlovnice.unos_id) AS unos_id,\r\n"
			+ "SUM(utrosasveposlovnice.bt550proizvodnja) AS bt550proizvodnja,\r\n"
			+ "SUM(utrosasveposlovnice.pt850proizvodnja) AS pt850proizvodnja,\r\n"
			+ "SUM(utrosasveposlovnice.ct110proizvodnja) AS ct110proizvodnja, \r\n"
			+ "SUM(utrosasveposlovnice.razbproizvodnja) AS razbproizvodnja,\r\n"
			+ "SUM(utrosasveposlovnice.kukbproizvodnja) AS kukbproizvodnja, \r\n"
			+ "SUM(utrosasveposlovnice.mjesbproizvodnja) AS mjesbproizvodnja,\r\n"
			+ "SUM(utrosasveposlovnice.posvrstebproizvodnja) AS posvrstebproizvodnja, \r\n"
			+ "SUM(utrosasveposlovnice.pecbproizvodnja) AS pecbproizvodnja,\r\n"
			+ "SUM(utrosasveposlovnice.ostproizvodibproizvodnja) AS ostproizvodibproizvodnja, \r\n"
			+ "SUM(utrosasveposlovnice.smjbproizvodnja) AS smjbproizvodnja,\r\n"
			+ "SUM(utrosasveposlovnice.konbproizvodnja) AS konbproizvodnja, \r\n"
			+ "SUM(utrosasveposlovnice.ukupnoproizvodnja) AS ukupnoproizvodnja,\r\n"
			+ "\r\n"
			+ "SUM(utrosasveposlovnice.bt550potrosnja) AS bt550potrosnja,\r\n"
			+ "SUM(utrosasveposlovnice.pt850potrosnja) AS pt850potrosnja,\r\n"
			+ "SUM(utrosasveposlovnice.ct110potrosnja) AS ct110potrosnja, \r\n"
			+ "SUM(utrosasveposlovnice.razbpotrosnja) AS razbpotrosnja,\r\n"
			+ "SUM(utrosasveposlovnice.kukbpotrosnja) AS kukbpotrosnja, \r\n"
			+ "SUM(utrosasveposlovnice.smjbpotrosnja) AS smjbpotrosnja,\r\n"
			+ "SUM(utrosasveposlovnice.konbpotrosnja) AS konbpotrosnja, \r\n"
			+ "SUM(utrosasveposlovnice.ukupnopotrosnja) AS ukupnopotrosnja,\r\n"
			+ "utrosasveposlovnice.odabranidatum,\r\n"
			+ "count(utrosasveposlovnice.poslovnica) as poslovnica\r\n"
			+ "FROM utrosasveposlovnice where utrosasveposlovnice.odabranidatum = ?1 GROUP BY utrosasveposlovnice.odabranidatum")
	public List<Knjiga> proba(LocalDate datum);
	
	

	
//	@Query(nativeQuery = true, value ="select * from utrosasveposlovnice where odabranidatum = ?1 and poslovnica = 1")
//	public List<Knjiga> dohvatiVoltino(LocalDate datum);
//	
//	@Query(nativeQuery = true, value ="select * from utrosasveposlovnice where odabranidatum = ?1 and poslovnica = 2")
//	public List<Knjiga> dohvatiJarun(LocalDate datum);
//	
//	@Query(nativeQuery = true, value ="select * from utrosasveposlovnice where odabranidatum = ?1 and poslovnica = 3")
//	public List<Knjiga> dohvatiVrbik(LocalDate datum);
	
	

}
