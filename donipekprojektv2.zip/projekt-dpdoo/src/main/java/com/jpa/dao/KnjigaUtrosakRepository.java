package com.jpa.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.jpa.model.KnjigaUtrosak;

@Repository
public interface KnjigaUtrosakRepository extends PagingAndSortingRepository<KnjigaUtrosak, Long> {
	
	@Query(nativeQuery = true, value = "SELECT sum(utrosasveposlovnice.unos_id) AS unos_id,"
			+ " SUM(utrosasveposlovnice.bt550potrosnja) AS bt550potrosnja,"
			+ "	SUM(utrosasveposlovnice.pt850potrosnja) AS pt850potrosnja,"
			+ "	SUM(utrosasveposlovnice.ct110potrosnja) AS ct110potrosnja,"
			+ "	SUM(utrosasveposlovnice.razbpotrosnja) AS razbpotrosnja,"
			+ "	SUM(utrosasveposlovnice.kukbpotrosnja) AS kukbpotrosnja,"
			+ "	SUM(utrosasveposlovnice.smjbpotrosnja) AS smjbpotrosnja,"
			+ "	SUM(utrosasveposlovnice.konbpotrosnja) AS konbpotrosnja,"
			+ "	SUM(utrosasveposlovnice.ukupnopotrosnja) AS ukupnopotrosnja,"
			+ "	(select utrosasveposlovnice.odabranidatum"
			+ "	from utrosasveposlovnice"
			+ "	where utrosasveposlovnice.odabranidatum= ?2"
			+ "	AND utrosasveposlovnice.poslovnica=2)"
			+ " as datum_od,"
			+ "	(select utrosasveposlovnice.odabranidatum"
			+ "	from utrosasveposlovnice"
			+ "	where utrosasveposlovnice.odabranidatum= ?2"
			+ "	AND utrosasveposlovnice.poslovnica=2) as datum_do"
			+ "	FROM utrosasveposlovnice"
			+ "	where utrosasveposlovnice.odabranidatum >= ?1"
			+ "	AND utrosasveposlovnice.odabranidatum <= ?2"
			+ "	AND (utrosasveposlovnice.poslovnica = 2"
			+ "	OR utrosasveposlovnice.poslovnica = 3) ")
	public KnjigaUtrosak dohvatiJarVrb(LocalDate datumOd, LocalDate datumDo);
	
	

}
