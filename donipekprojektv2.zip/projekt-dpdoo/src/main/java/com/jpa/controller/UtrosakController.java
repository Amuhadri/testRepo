package com.jpa.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jpa.dao.KnjigaUtrosakRepository;
import com.jpa.model.KnjigaUtrosak;
import com.jpa.services.KnjigaUtroskaServices;

@Controller
@RequestMapping("utrosak")
public class UtrosakController {
	
	@Autowired
	KnjigaUtrosakRepository utrRepo;
	
	@Autowired
	KnjigaUtroskaServices knjUtrSrv;
	
	
	@GetMapping("/sve")
	public String odaberiDatumPregleda(Model model, KnjigaUtrosak knjigaUtrosak) {
		return "pregled-utroska";
	}
	
	@PostMapping("/sve")
	public String prikaziUtrosak(Model model, KnjigaUtrosak knjigaUtrosak) throws IOException {
	
		Date datumOd = knjigaUtrosak.getDatumOd();
		Date datumDo = knjigaUtrosak.getDatumDo();
		KnjigaUtrosak objektZbroj =  knjUtrSrv.zbrojiSve(utrRepo.dohvatiJarVrb(datumOd.toLocalDate(), datumDo.toLocalDate()), knjigaUtrosak);
		List<KnjigaUtrosak> utrosakZbroj = new ArrayList<>();
		utrosakZbroj.add(objektZbroj);
		model.addAttribute("utrosakZbroj", utrosakZbroj);

		return "pregled-utroska";
	}

}
