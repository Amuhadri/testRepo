package com.jpa.services;

import org.springframework.stereotype.Service;

import com.jpa.model.KnjigaUtrosak;

@Service
public class KnjigaUtroskaServices {

	public KnjigaUtrosak sprtemiPodatkeUListu(KnjigaUtrosak knjUtr) {

		KnjigaUtrosak utrosakVoltino = new KnjigaUtrosak();

		utrosakVoltino.setBijT550Potrosnja(knjUtr.getBijT550Potrosnja());
		utrosakVoltino.setPolT850Potrosnja(knjUtr.getPolT850Potrosnja());
		utrosakVoltino.setCrnT110Potrosnja(knjUtr.getCrnT110Potrosnja());
		utrosakVoltino.setRazBPotrosnja(knjUtr.getRazBPotrosnja());
		utrosakVoltino.setKukBPotrosnja(knjUtr.getKukBPotrosnja());
		utrosakVoltino.setSmjBPotrosnja(knjUtr.getSmjBPotrosnja());
		utrosakVoltino.setKonBPotrosnja(knjUtr.getKonBPotrosnja());

		return utrosakVoltino;

	}

	public KnjigaUtrosak zbrojiSve(KnjigaUtrosak knjJarVrb, KnjigaUtrosak knjVoltino) {

		KnjigaUtrosak zbrojObjekta = new KnjigaUtrosak();
		try {

			
			zbrojObjekta.setBijT550Potrosnja(knjVoltino.getBijT550Potrosnja() - knjJarVrb.getBijT550Potrosnja());
			zbrojObjekta.setPolT850Potrosnja(knjVoltino.getPolT850Potrosnja() - knjJarVrb.getPolT850Potrosnja());
			zbrojObjekta.setCrnT110Potrosnja(knjVoltino.getCrnT110Potrosnja() - knjJarVrb.getCrnT110Potrosnja());
			zbrojObjekta.setRazBPotrosnja(knjVoltino.getRazBPotrosnja() - knjJarVrb.getRazBPotrosnja());
			zbrojObjekta.setKukBPotrosnja(knjVoltino.getKukBPotrosnja() - knjJarVrb.getKukBPotrosnja());
			zbrojObjekta.setSmjBPotrosnja(knjVoltino.getSmjBPotrosnja() - knjJarVrb.getSmjBPotrosnja());
			zbrojObjekta.setKonBPotrosnja(knjVoltino.getKonBPotrosnja() - knjJarVrb.getKonBPotrosnja());

		} catch (Exception e) {
			System.out.println("Nema podatka za taj period!");
		}

		return zbrojObjekta;

	}
}
