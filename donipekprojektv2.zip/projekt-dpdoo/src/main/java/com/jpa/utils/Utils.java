package com.jpa.utils;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {


	public static String makniRazmake(String stringTxt) {

		stringTxt = stringTxt.replaceAll("\\s+", "");
		return stringTxt;

	}

	public static String formatDatumaVremena() {

		Format f = new SimpleDateFormat("dd/MM/yy ** hh-mm-ss");
		String datum = " \n".concat(f.format(new Date()));

		return datum;
	}
	
	


}
