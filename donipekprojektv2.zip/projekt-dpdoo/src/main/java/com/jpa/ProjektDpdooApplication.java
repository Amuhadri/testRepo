package com.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjektDpdooApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjektDpdooApplication.class, args);
	}

}
