package com.jpa.model;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "utrosasveposlovnice")
public class Knjiga {

	@Id
	@Column(name = "unos_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY) //identity - ako je baza kreirana pa da se nastavi numeriranje od 1, AUTO ako zelimo da automatski ide od 1 pa nadalje, sequ
	private long idKnjige;
	
	@Column(name = "bt550proizvodnja")
	private double bijT550Proizvodnja;
	
	@Column(name = "pt850proizvodnja")
	private double polT850Proizvodnja;
	
	@Column(name = "ct110proizvodnja")
	private double crnT110Proizvodnja;
	
	@Column(name = "razbproizvodnja")
	private double razBProizvodnja;
	
	@Column(name = "kukbproizvodnja")
	private double kukBProizvodnja;
	
	@Column(name = "mjesbproizvodnja")
	private double mjesBProizvodnja;
	
	@Column(name = "posvrstebproizvodnja")
	private double posVrsteBProizvodnja;
	
	@Column(name = "pecbproizvodnja")
	private double pecBProizvodnja;
	
	@Column(name = "ostproizvodibproizvodnja")
	private double ostProizvodiBproizvodnja;
	
	@Column(name = "smjbproizvodnja")
	private double smjBProizvodnja;
	
	@Column(name = "konbproizvodnja")
	private double konBProizvodnja;
	
	@Column(name = "ukupnoproizvodnja")
	private double ukupnoProizvodnja;

	
	@Column(name = "bt550potrosnja")
	private double bijT550Potrosnja;
	
	@Column(name = "pt850potrosnja")
	private double polT850Potrosnja;
	
	@Column(name = "ct110potrosnja")
	private double crnT110Potrosnja;
	
	@Column(name = "razbpotrosnja")
	private double razBPotrosnja;
	
	@Column(name = "kukbpotrosnja")
	private double kukBPotrosnja;
	
	@Column(name = "smjbpotrosnja")
	private double smjBPotrosnja;
	
	@Column(name = "konbpotrosnja")
	private double konBPotrosnja;
	
	@Column(name = "ukupnopotrosnja")
	private double ukupnoPotrosnja;
	
	@Column(name = "poslovnica")
	private int poslovnica;
	
	@Column(name = "odabranidatum")
	private Date odabraniDatum;
	

	public Knjiga() {

	}

	public Knjiga(double bijT550Proizvodnja, double polT850Proizvodnja) {
		super();
		this.bijT550Proizvodnja = bijT550Proizvodnja;
		this.polT850Proizvodnja = polT850Proizvodnja;
	}
	
	
	public Knjiga(double bijT550Proizvodnja, double polT850Proizvodnja, double crnT110Proizvodnja,
			double razBProizvodnja, double kukBProizvodnja, double mjesBProizvodnja, double posVrsteBProizvodnja,
			double pecBProizvodnja, double ostProizvodiBproizvodnja, double smjBProizvodnja, double konBProizvodnja,
			double ukupnoProizvodnja, double bijT550Potrosnja, double polT850Potrosnja, double crnT110Potrosnja,
			double razBPotrosnja, double kukBPotrosnja, double smjBPotrosnja, double konBPotrosnja,
			double ukupnoPotrosnja, int poslovnica, Date odabraniDatum) {
		super();
		this.bijT550Proizvodnja = bijT550Proizvodnja;
		this.polT850Proizvodnja = polT850Proizvodnja;
		this.crnT110Proizvodnja = crnT110Proizvodnja;
		this.razBProizvodnja = razBProizvodnja;
		this.kukBProizvodnja = kukBProizvodnja;
		this.mjesBProizvodnja = mjesBProizvodnja;
		this.posVrsteBProizvodnja = posVrsteBProizvodnja;
		this.pecBProizvodnja = pecBProizvodnja;
		this.ostProizvodiBproizvodnja = ostProizvodiBproizvodnja;
		this.smjBProizvodnja = smjBProizvodnja;
		this.konBProizvodnja = konBProizvodnja;
		this.ukupnoProizvodnja = ukupnoProizvodnja;
		this.bijT550Potrosnja = bijT550Potrosnja;
		this.polT850Potrosnja = polT850Potrosnja;
		this.crnT110Potrosnja = crnT110Potrosnja;
		this.razBPotrosnja = razBPotrosnja;
		this.kukBPotrosnja = kukBPotrosnja;
		this.smjBPotrosnja = smjBPotrosnja;
		this.konBPotrosnja = konBPotrosnja;
		this.ukupnoPotrosnja = ukupnoPotrosnja;
		this.poslovnica =poslovnica;
		this.odabraniDatum = odabraniDatum;
	}

	public long getIdKnjige() {
		return idKnjige;
	}

	public void setIdKnjige(long idKnjige) {
		this.idKnjige = idKnjige;
	}

	public double getBijT550Proizvodnja() {
		return bijT550Proizvodnja;
	}

	public void setBijT550Proizvodnja(double bijT550Proizvodnja) {
		this.bijT550Proizvodnja = bijT550Proizvodnja;
	}

	public double getPolT850Proizvodnja() {
		return polT850Proizvodnja;
	}

	public void setPolT850Proizvodnja(double polT850Proizvodnja) {
		this.polT850Proizvodnja = polT850Proizvodnja;
	}

	public double getCrnT110Proizvodnja() {
		return crnT110Proizvodnja;
	}

	public void setCrnT110Proizvodnja(double crnT110Proizvodnja) {
		this.crnT110Proizvodnja = crnT110Proizvodnja;
	}

	public double getRazBProizvodnja() {
		return razBProizvodnja;
	}

	public void setRazBProizvodnja(double razBProizvodnja) {
		this.razBProizvodnja = razBProizvodnja;
	}

	public double getKukBProizvodnja() {
		return kukBProizvodnja;
	}

	public void setKukBProizvodnja(double kukBProizvodnja) {
		this.kukBProizvodnja = kukBProizvodnja;
	}

	public double getMjesBProizvodnja() {
		return mjesBProizvodnja;
	}

	public void setMjesBProizvodnja(double mjesBProizvodnja) {
		this.mjesBProizvodnja = mjesBProizvodnja;
	}

	public double getPosVrsteBProizvodnja() {
		return posVrsteBProizvodnja;
	}

	public void setPosVrsteBProizvodnja(double posVrsteBProizvodnja) {
		this.posVrsteBProizvodnja = posVrsteBProizvodnja;
	}

	public double getPecBProizvodnja() {
		return pecBProizvodnja;
	}

	public void setPecBProizvodnja(double pecBProizvodnja) {
		this.pecBProizvodnja = pecBProizvodnja;
	}

	public double getOstProizvodiBproizvodnja() {
		return ostProizvodiBproizvodnja;
	}

	public void setOstProizvodiBproizvodnja(double ostProizvodiBproizvodnja) {
		this.ostProizvodiBproizvodnja = ostProizvodiBproizvodnja;
	}

	public double getSmjBProizvodnja() {
		return smjBProizvodnja;
	}

	public void setSmjBProizvodnja(double smjBProizvodnja) {
		this.smjBProizvodnja = smjBProizvodnja;
	}

	public double getKonBProizvodnja() {
		return konBProizvodnja;
	}

	public void setKonBProizvodnja(double konBProizvodnja) {
		this.konBProizvodnja = konBProizvodnja;
	}

	public double getUkupnoProizvodnja() {
		return ukupnoProizvodnja;
	}

	public void setUkupnoProizvodnja(double ukupnoProizvodnja) {
		this.ukupnoProizvodnja = ukupnoProizvodnja;
	}

	public double getBijT550Potrosnja() {
		return bijT550Potrosnja;
	}

	public void setBijT550Potrosnja(double bijT550Potrosnja) {
		this.bijT550Potrosnja = bijT550Potrosnja;
	}

	public double getPolT850Potrosnja() {
		return polT850Potrosnja;
	}

	public void setPolT850Potrosnja(double polT850Potrosnja) {
		this.polT850Potrosnja = polT850Potrosnja;
	}

	public double getCrnT110Potrosnja() {
		return crnT110Potrosnja;
	}

	public void setCrnT110Potrosnja(double crnT110Potrosnja) {
		this.crnT110Potrosnja = crnT110Potrosnja;
	}

	public double getRazBPotrosnja() {
		return razBPotrosnja;
	}

	public void setRazBPotrosnja(double razBPotrosnja) {
		this.razBPotrosnja = razBPotrosnja;
	}

	public double getKukBPotrosnja() {
		return kukBPotrosnja;
	}

	public void setKukBPotrosnja(double kukBPotrosnja) {
		this.kukBPotrosnja = kukBPotrosnja;
	}

	public double getSmjBPotrosnja() {
		return smjBPotrosnja;
	}

	public void setSmjBPotrosnja(double smjBPotrosnja) {
		this.smjBPotrosnja = smjBPotrosnja;
	}

	public double getKonBPotrosnja() {
		return konBPotrosnja;
	}

	public void setKonBPotrosnja(double konBPotrosnja) {
		this.konBPotrosnja = konBPotrosnja;
	}

	public double getUkupnoPotrosnja() {
		return ukupnoPotrosnja;
	}

	public void setUkupnoPotrosnja(double ukupnoPotrosnja) {
		this.ukupnoPotrosnja = ukupnoPotrosnja;
	}

	public int getPoslovnica() {
		return poslovnica;
	}

	public void setPoslovnica(int poslovnica) {
		this.poslovnica = poslovnica;
	}

	public Date getOdabraniDatum() {
		return odabraniDatum;
	}

	public void setOdabraniDatum(Date odabraniDatum) {
		this.odabraniDatum = odabraniDatum;
	}


	
	

}
