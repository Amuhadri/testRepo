package com.jpa.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "utrosasveposlovnice")
public class KnjigaUtrosak {
	
	@Id
	@Column(name = "unos_id")
	private long idKnjige;
	
	@Column(name = "bt550potrosnja")
	private double bijT550Potrosnja;
	
	@Column(name = "pt850potrosnja")
	private double polT850Potrosnja;
	
	@Column(name = "ct110potrosnja")
	private double crnT110Potrosnja;
	
	@Column(name = "razbpotrosnja")
	private double razBPotrosnja;
	
	@Column(name = "kukbpotrosnja")
	private double kukBPotrosnja;
	
	@Column(name = "smjbpotrosnja")
	private double smjBPotrosnja;
	
	@Column(name = "konbpotrosnja")
	private double konBPotrosnja;
	
	@Column(name = "ukupnopotrosnja")
	private double ukupnoPotrosnja;
	
	@Column(name = "datumOd")
	private Date datumOd;
	
	@Column(name = "datumDo")
	private Date datumDo;
	
	public KnjigaUtrosak() {
		
	}
	
	public KnjigaUtrosak(double bijT550Potrosnja, double polT850Potrosnja, double crnT110Potrosnja,
			double razBPotrosnja, double kukBPotrosnja, double smjBPotrosnja, double konBPotrosnja,
			double ukupnoPotrosnja, Date datumOd, Date datumDo) {
		super();
		this.bijT550Potrosnja = bijT550Potrosnja;
		this.polT850Potrosnja = polT850Potrosnja;
		this.crnT110Potrosnja = crnT110Potrosnja;
		this.razBPotrosnja = razBPotrosnja;
		this.kukBPotrosnja = kukBPotrosnja;
		this.smjBPotrosnja = smjBPotrosnja;
		this.konBPotrosnja = konBPotrosnja;
		this.ukupnoPotrosnja = ukupnoPotrosnja;
		this.datumOd = datumOd;
		this.datumDo = datumDo;
	}


	public long getIdKnjige() {
		return idKnjige;
	}

	public void setIdKnjige(long idKnjige) {
		this.idKnjige = idKnjige;
	}

	public double getBijT550Potrosnja() {
		return bijT550Potrosnja;
	}

	public void setBijT550Potrosnja(double bijT550Potrosnja) {
		this.bijT550Potrosnja = bijT550Potrosnja;
	}

	public double getPolT850Potrosnja() {
		return polT850Potrosnja;
	}

	public void setPolT850Potrosnja(double polT850Potrosnja) {
		this.polT850Potrosnja = polT850Potrosnja;
	}

	public double getCrnT110Potrosnja() {
		return crnT110Potrosnja;
	}

	public void setCrnT110Potrosnja(double crnT110Potrosnja) {
		this.crnT110Potrosnja = crnT110Potrosnja;
	}

	public double getRazBPotrosnja() {
		return razBPotrosnja;
	}

	public void setRazBPotrosnja(double razBPotrosnja) {
		this.razBPotrosnja = razBPotrosnja;
	}

	public double getKukBPotrosnja() {
		return kukBPotrosnja;
	}

	public void setKukBPotrosnja(double kukBPotrosnja) {
		this.kukBPotrosnja = kukBPotrosnja;
	}

	public double getSmjBPotrosnja() {
		return smjBPotrosnja;
	}

	public void setSmjBPotrosnja(double smjBPotrosnja) {
		this.smjBPotrosnja = smjBPotrosnja;
	}

	public double getKonBPotrosnja() {
		return konBPotrosnja;
	}

	public void setKonBPotrosnja(double konBPotrosnja) {
		this.konBPotrosnja = konBPotrosnja;
	}

	public double getUkupnoPotrosnja() {
		return ukupnoPotrosnja;
	}

	public void setUkupnoPotrosnja(double ukupnoPotrosnja) {
		this.ukupnoPotrosnja = ukupnoPotrosnja;
	}



	public Date getDatumOd() {
		return datumOd;
	}


	public void setDatumOd(Date datumOd) {
		this.datumOd = datumOd;
	}


	public Date getDatumDo() {
		return datumDo;
	}


	public void setDatumDo(Date datumDo) {
		this.datumDo = datumDo;
	}


	
	
	
	
}
